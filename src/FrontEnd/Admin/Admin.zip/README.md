<!--
 * @Author: Li-HONGYAO
 * @Date: 2021-01-17 23:30:37
 * @LastEditTime: 2021-02-24 21:49:01
 * @LastEditors: Li-HONGYAO
 * @Description: 
 * @FilePath: /Admin/README.md
-->
# umi project

## Getting Started

Install dependencies,

```bash
$ yarn
```

Start the dev server,

```bash
$ yarn start
```


<!-- 订单状态 -->
待支付100、
待发货/已预约200、
进行中（技师点击开始服务）300
已发货/待接取400、
已收货/已完成500、拒绝退款501 完成退款502
申请退款\售后 600 、退货售后中 601