import React from 'react';
export default () => {
  return <div className="page lazy-loading"></div>;
}