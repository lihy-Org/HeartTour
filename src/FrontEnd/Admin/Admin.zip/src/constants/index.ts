/*
 * @Author: Li-HONGYAO
 * @Date: 2021-02-23 17:54:59
 * @LastEditTime: 2021-03-01 17:14:24
 * @LastEditors: Li-HONGYAO
 * @Description:
 * @FilePath: /Admin/src/constants/index.ts
 */

export const kPOST = 'kPOST'; /** 职位管理 */
export const kTITLE = 'kTITLE'; /** 头衔管理 */
export const kVARIETIES = 'kVARIETIES'; /** 宠物品种 */
export const kGOODS_CLASSIFY = 'kGOODS_CLASSIFY'; /** 商品分类 */
