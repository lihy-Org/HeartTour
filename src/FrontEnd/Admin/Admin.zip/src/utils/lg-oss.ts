/*
 * @Author: Li-HONGYAO
 * @Date: 2021-03-09 14:31:42
 * @LastEditTime: 2021-03-09 14:31:57
 * @LastEditors: Li-HONGYAO
 * @Description: 
 * @FilePath: /Admin/src/utils/lg-oss.ts
 */


import OSS from 'ali-oss';


