import React, { FC } from 'react';

const Store: FC = () => {
  return <div className="page">门店账目管理</div>;
};

export default Store;
