import React, { FC } from 'react';

const Shop: FC = () => {
  return <div className="page">商城账目管理</div>;
};

export default Shop;
