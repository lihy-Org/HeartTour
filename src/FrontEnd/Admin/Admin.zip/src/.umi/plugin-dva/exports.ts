// @ts-nocheck

export { connect, useDispatch, useStore, useSelector } from 'dva';
export { getApp as getDvaApp } from './dva';
